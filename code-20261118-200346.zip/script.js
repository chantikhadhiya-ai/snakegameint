const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');
const bestEl = document.getElementById('best');
const levelEl = document.getElementById('level');
const overlay = document.getElementById('overlay');
const overlayIcon = document.getElementById('overlayIcon');
const overlayTitle = document.getElementById('overlayTitle');
const overlayText = document.getElementById('overlayText');
const startBtn = document.getElementById('startBtn');

const cells = 24;
const cellSize = canvas.width / cells;
let snake;
let food;
let direction;
let nextDirection;
let score = 0;
let best = Number(localStorage.getItem('neonSnakeBest')) || 0;
let timer = null;
let running = false;
let ended = false;
bestEl.textContent = formatScore(best);

function formatScore(value) {
  return String(value).padStart(3, '0');
}

function resetGame() {
  snake = [
    { x: 10, y: 12 },
    { x: 9, y: 12 },
    { x: 8, y: 12 },
    { x: 7, y: 12 }
  ];
  direction = { x: 1, y: 0 };
  nextDirection = { x: 1, y: 0 };
  score = 0;
  ended = false;
  scoreEl.textContent = formatScore(score);
  levelEl.textContent = '1';
  placeFood();
  draw();
}

function placeFood() {
  do {
    food = { x: Math.floor(Math.random() * cells), y: Math.floor(Math.random() * cells) };
  } while (snake.some(part => part.x === food.x && part.y === food.y));
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#0c1622';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = 'rgba(128, 155, 180, 0.07)';
  ctx.lineWidth = 1;
  for (let i = 1; i < cells; i++) {
    const pos = i * cellSize;
    ctx.beginPath();
    ctx.moveTo(pos, 0);
    ctx.lineTo(pos, canvas.height);
    ctx.moveTo(0, pos);
    ctx.lineTo(canvas.width, pos);
    ctx.stroke();
  }

  const foodX = food.x * cellSize + cellSize / 2;
  const foodY = food.y * cellSize + cellSize / 2;
  ctx.shadowColor = '#ff6478';
  ctx.shadowBlur = 15;
  ctx.fillStyle = '#ff6478';
  ctx.beginPath();
  ctx.arc(foodX, foodY, cellSize * 0.31, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#ffd1d5';
  ctx.beginPath();
  ctx.arc(foodX - 2, foodY - 2, cellSize * 0.09, 0, Math.PI * 2);
  ctx.fill();

  snake.forEach((part, index) => {
    const inset = 2;
    const x = part.x * cellSize + inset;
    const y = part.y * cellSize + inset;
    const size = cellSize - inset * 2;
    ctx.fillStyle = index === 0 ? '#a8ff7a' : `hsl(105, 75%, ${Math.max(42, 62 - index * 0.45)}%)`;
    ctx.shadowColor = index === 0 ? '#8cf06b' : 'transparent';
    ctx.shadowBlur = index === 0 ? 13 : 0;
    roundedRect(x, y, size, size, 5);
    ctx.fill();

    if (index === 0) {
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#15251a';
      const eyeOffsetX = direction.x === 0 ? 0 : direction.x * 2.2;
      const eyeOffsetY = direction.y === 0 ? 0 : direction.y * 2.2;
      const eye1X = x + size / 2 - 3 + eyeOffsetX;
      const eye2X = x + size / 2 + 3 + eyeOffsetX;
      const eyeY = y + size / 2 - 2 + eyeOffsetY;
      ctx.beginPath();
      ctx.arc(eye1X, eyeY, 1.25, 0, Math.PI * 2);
      ctx.arc(eye2X, eyeY, 1.25, 0, Math.PI * 2);
      ctx.fill();
    }
  });
  ctx.shadowBlur = 0;
}

function roundedRect(x, y, width, height, radius) {
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, radius);
}

function tick() {
  direction = nextDirection;
  const head = { x: snake[0].x + direction.x, y: snake[0].y + direction.y };
  const eating = head.x === food.x && head.y === food.y;
  const body = eating ? snake : snake.slice(0, -1);

  if (head.x < 0 || head.x >= cells || head.y < 0 || head.y >= cells || body.some(part => part.x === head.x && part.y === head.y)) {
    gameOver();
    return;
  }

  snake.unshift(head);
  if (eating) {
    score += 10;
    scoreEl.textContent = formatScore(score);
    if (score > best) {
      best = score;
      bestEl.textContent = formatScore(best);
      localStorage.setItem('neonSnakeBest', best);
    }
    levelEl.textContent = String(Math.floor(score / 50) + 1);
    placeFood();
    if (score % 50 === 0) setSpeed();
  } else {
    snake.pop();
  }
  draw();
}

function setSpeed() {
  if (!running) return;
  clearInterval(timer);
  timer = setInterval(tick, Math.max(65, 135 - Math.floor(score / 50) * 10));
}

function startGame() {
  if (ended) resetGame();
  if (running) return;
  running = true;
  overlay.classList.add('hidden');
  setSpeed();
}

function pauseGame() {
  if (!running) return;
  running = false;
  clearInterval(timer);
  showOverlay('Ⅱ', 'Permainan dijeda', 'Tarik napas sebentar. Lanjutkan saat kamu siap!', 'Lanjutkan bermain');
}

function gameOver() {
  running = false;
  ended = true;
  clearInterval(timer);
  showOverlay('✦', 'Game over!', `Skormu ${formatScore(score)}. Coba lagi dan pecahkan rekor!`, 'Main lagi');
}

function showOverlay(icon, title, text, buttonText) {
  overlayIcon.textContent = icon;
  overlayTitle.textContent = title;
  overlayText.textContent = text;
  startBtn.innerHTML = `${buttonText} <span>→</span>`;
  overlay.classList.remove('hidden');
}

function changeDirection(x, y) {
  if (!running) return;
  if (x === -nextDirection.x && y === -nextDirection.y) return;
  nextDirection = { x, y };
}

document.addEventListener('keydown', event => {
  const key = event.key.toLowerCase();
  const controls = {
    arrowup: [0, -1], w: [0, -1],
    arrowdown: [0, 1], s: [0, 1],
    arrowleft: [-1, 0], a: [-1, 0],
    arrowright: [1, 0], d: [1, 0]
  };
  if (controls[key]) {
    event.preventDefault();
    if (!running && !ended) startGame();
    changeDirection(...controls[key]);
  } else if (key === ' ') {
    event.preventDefault();
    if (running) pauseGame();
    else startGame();
  }
});

startBtn.addEventListener('click', startGame);
document.getElementById('restartBtn').addEventListener('click', () => {
  clearInterval(timer);
  running = false;
  resetGame();
  startGame();
});

let touchStart = null;
canvas.addEventListener('touchstart', event => {
  const touch = event.changedTouches[0];
  touchStart = { x: touch.clientX, y: touch.clientY };
}, { passive: true });
canvas.addEventListener('touchend', event => {
  if (!touchStart) return;
  const touch = event.changedTouches[0];
  const dx = touch.clientX - touchStart.x;
  const dy = touch.clientY - touchStart.y;
  touchStart = null;
  if (Math.max(Math.abs(dx), Math.abs(dy)) < 15) return;
  if (!running) startGame();
  if (Math.abs(dx) > Math.abs(dy)) changeDirection(Math.sign(dx), 0);
  else changeDirection(0, Math.sign(dy));
}, { passive: true });

resetGame();
